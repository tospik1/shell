#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>

#define MAX_JOBS 50

int fgProcId=-1;
int jobPids[MAX_JOBS];

// Signal handlers
static void sigintHandler(int sig);
static void sigtstpHandler(int sig);

// Checks if it's built in command runs it and returns 1
// If not it does noting and returns 0
// args last element is NULL signifiying end of list, all other functions here also do that way
int tryBuiltIn(char* file, char* args[]);

// Executes command along with it's command line options, no redirection/piping/background is done here
void execCmd(char* file, char* args[]);

// Execute piped command, the pIndex is the pipe position, 1st command is 0..pIndex-1 and 2nd is pIndex+1..last
void execPipe(char* args[], int pIndex);

// args is the command, file is the file name
void execOutRedir(char* args[], char* file);

// General execute function, here process will be forked and executed
// If there's no pipe or redirection then < 0 value should be given to pipePos or redirPos respectively
// This function doesn't execute multiple pipes or pipe and redirection at same time, redirection is only for output
void execute(char *args[], int pipePos, int redirPos, int bg);

// Parses the command prompt, fills args with commands and NULL at end, sets background flag, returns number of commands
int getcmd(char *prompt, char *args[], int *background);

// Built in functions
void funcCd(char *file, char *args[]);
void funcPwd(char *file, char *args[]);
void funcExit(char *file, char *args[]);
void funcFg(char *file, char *args[]);
void funcJobs(char *file, char *args[]);

int main(void) {
    // Initialisation
    if (signal(SIGINT, sigintHandler) == SIG_ERR) {
        printf("ERROR! Could not bind the SIGINT signal handler\n");
    }
    if (signal(SIGTSTP, sigtstpHandler) == SIG_ERR) {
        printf("ERROR! Could not bind the SIGTSTP signal handler\n");
    }
    for (int i = 0; i < MAX_JOBS; ++i) {
        jobPids[i] = -1;
    }
    char *args[20];
    int bg;

    // Main loop
    while(1) {
        bg = 0;
        int cnt = getcmd("\n>>", args, &bg);
        if (cnt == 0) {
            continue;
        }
        // Update jobs list, remove finished ones
        for (int i = 0; i < MAX_JOBS; ++i) {
            if (jobPids[i] > 0) { // There's a job id at current element, check it's status
                int status;
                pid_t return_pid = waitpid(jobPids[i], &status, WNOHANG);
                if (return_pid == -1) {
                    printf("Error: can't check if child process is finished or not\n");
                } else if (return_pid == jobPids[i]) {
                    jobPids[i] = 0;
                }
            }
        }
        if (strcmp(args[cnt-1], ">") == 0 || strcmp(args[cnt-1], "|") == 0) {
            printf("Error: last item is | or >, should specify command or file afterward\n");
        }
        int executed = 0; // Will check to see if pipe or redirection is executed, otherwise execute plain command
            for (int i = 0; i+1 < cnt; ++i) {
                if (strcmp(args[i], "|") == 0) {
                    args[i] = NULL;
                    // fg and exit needs to be handled inside main process
                    // they will be runned independent of the other part of process, and they don't have input/output to be affected
                    if (strcmp(args[0], "fg") == 0) {
                        funcFg(args[0], args);
                        execute(args+i+1, -1, -1, bg);
                    } else if (strcmp(args[i+1], "fg") == 0) {
                        execute(args, -1, -1, bg);
                        funcFg(args[i+1], args+i+1);
                    } else if (strcmp(args[0], "exit") == 0) {
                        funcExit(args[0], args);
                    } else if (strcmp(args[i+1], "exit") == 0) {
                        execute(args, -1, -1, bg);
                        funcExit(args[i+1], args+i+1);
                    } else {
                        execute(args, i, -1, bg);
                    }
                    executed = 1;
                    break;
                } else if (strcmp(args[i], ">") == 0) {
                    if (strcmp(args[0], "fg") == 0) {
                        FILE* fd = fopen(args[i+1], "w");
                        fclose(fd);
                    }
                    args[i] = NULL;
                    execute(args, -1, i, bg);
                    executed = 1;
                    break;
                }
            }
            //If no piping or redirection execute normally
            if (!executed) {
                if (strcmp(args[0], "fg") == 0) {
                    funcFg(args[0], args);
                } else if (strcmp(args[0], "exit") == 0) {
                    funcExit(args[0], args);
                } else {
                    execute(args, -1, -1, bg);
                }
            }
    }
    return 0;
}

static void sigintHandler(int sig) {
    if (fgProcId > 0) {
        kill(fgProcId, SIGINT);
        fgProcId = -1;
    }
}
static void sigtstpHandler(int sig) {}


int tryBuiltIn(char* file, char* args[]) {
    if (strcmp(args[0], "cd") == 0) {
        funcCd(file, args);
        return 1;
    } else if (strcmp(args[0], "pwd") == 0) {
        funcPwd(file, args);
        return 1;
    } else if (strcmp(args[0], "exit") == 0) {
        funcExit(file, args);
        return 1;
    } else if (strcmp(args[0], "fg") == 0) {
        funcFg(file, args);
        return 1;
    } else if (strcmp(args[0], "jobs") == 0) {
        funcJobs(file, args);
        return 1;
    } else {
        return 0;
    }
    return 1;
}
void execCmd(char* file, char* args[]) {
    if (tryBuiltIn(args[0], args)) {
        exit(0); // If it's built in command, after executing there's nothing more to do for current child process
    } else {
        if(execvp(args[0], args) < 0){
            printf("Error when executing external command\n");
        }
        printf("Error when executing external command, control reached after execvp\n");
        exit(-1);
    }
}
void execPipe(char* args[], int pIndex) {
    int fd[2];	// Pipe file descriptors
    int pid1, pid2;

    if(pipe(fd) == -1){
        printf("Error when piping\n");
        return;
    }

    pid1 = fork();
    if(pid1 < 0){
        printf("Error when forking\n");
        return;
    }

    if(pid1 == 0){
        // In Child 1
        dup2(fd[1], STDOUT_FILENO);
        close(fd[0]);
        close(fd[1]);
        execCmd(args[0], args);
    }
    else{
        // In parent process
        pid2 = fork();
        if(pid2 < 0){
            printf("Error when forking\n");
            return;
        }
        if(pid2 == 0){
            // In Child 2
            dup2(fd[0], STDIN_FILENO);
            close(fd[0]);
            close(fd[1]);
            execCmd(args[pIndex+1], args+pIndex+1);
        }
        else{
            // Wait for children to finish executing
            close(fd[1]);
            close(fd[0]);
            waitpid(pid1, NULL, 0);
            waitpid(pid2, NULL, 0);
        }
    }
}

void execOutRedir(char* args[], char* file) {
    FILE* fd = fopen(file, "w");
    if (!fd) {
        printf("Error when opening file for redirection\n");
        return;
    }

    int pid = fork();
    if(pid < 0){
        printf("Error when forking\n");
        return;
    }

    if(pid == 0){
        // In Child
        dup2(fileno(fd), STDOUT_FILENO);
        fclose(fd);
        execCmd(args[0], args);
    } else {
        // In parent process
        // Wait for child to finish
        fclose(fd);
        waitpid(pid, NULL, 0);
    }
}

void execute(char *args[], int pipePos, int redirPos, int bg) {
    int pid;
    pid = fork();
    if (pid < 0){
        printf("Error when forking\n");
    }
    if (pid == 0){
        // In child process, check if pipe or redirection or nothing, and execute
        if (pipePos >= 0) {
            execPipe(args, pipePos);
        } else if (redirPos >= 0) {
            execOutRedir(args, args[redirPos+1]);
        } else {
            execCmd(args[0], args);
        }
    } else {
        // In parent process, the parent is the main shell process, here will handle background flag too
        if (!bg) { // Not background, wait until child will finish
            fgProcId = pid;
            waitpid(pid, NULL, 0);
        } else { // Background job
            // Find free place in jobs array to put it there, write the job id and process id to use later with fg
            int hadPutOnBackground=0; // To check if there's available space to put this backgound job
            for (int i = 0; i < MAX_JOBS; ++i) {
                if (jobPids[i] <= 0) {
                    hadPutOnBackground = 1;
                    jobPids[i] = pid;
                    printf("[%d] %d\n", i+1, pid);
                    break;
                }
            }
            if (!hadPutOnBackground) {
                printf("Too many background jobs (total %d), no more space available, you can't reference this job later, process id is: %d\n", MAX_JOBS, pid);
            }
        }
    }
}


int getcmd(char *prompt, char *args[], int *background)
{
    int length, i = 0;
    char *token, *loc;
    char *line = NULL;
    size_t linecap = 0;
    printf("%s", prompt);
    length = getline(&line, &linecap, stdin);
    if (length <= 0) {
        free(line);
        exit(-1);
    }
    // Check if background is specified..
    if ((loc = index(line, '&')) != NULL) {
        *background = 1;
        *loc = ' ';
    } else
        *background = 0;
    while ((token = strsep(&line, " \t\n")) != NULL) {
        int len = strlen(token);
        for (int j = 0; j < len; j++)
            if (token[j] <= 32)
                token[j] = '\0';
        if (len > 0)
            args[i++] = token;
    }
    args[i] = NULL;
    free(line);
    return i;
}

void funcFg(char *file, char *args[]) {
    if (!args[1]) {
        printf("fg: should specify 1 number argument\n");
        return;
    }
    int ind = atoi(args[1])-1;
    if (jobPids[ind] > 0) {
        fgProcId = jobPids[ind];
        jobPids[ind] = -1;
        printf("[%d] %d", ind+1, fgProcId);
        waitpid(fgProcId, NULL, 0);
    } else {
        printf("fg: current id job is invalid or already completed\n");
    }
}

void funcExit(char *file, char *args[]) {
    // Kill all active processes first, and then exit, this function is called from main shell process
    if (fgProcId > 0) {
        kill(fgProcId, SIGINT);
    }
    for (int i = 0; i < MAX_JOBS; ++i) {
        if (jobPids[i] > 0) {
            kill(jobPids[i], SIGINT);
        }
    }
    exit(0);
}

void funcCd(char *file, char *args[]) {
    if (!args[1]) {
        funcPwd(file, args);
    } else if (chdir(args[1]) < 0) {
        printf("cd: can't change directory, possibly it's invalid\n");
    }
}
void funcPwd(char *file, char *args[]) {
    char* buf = getcwd(NULL, 0);
    if (!buf) {
        printf("pwd: can't get the current directory\n");
    } else {
        printf("%s\n", buf);
        free(buf);
    }
}
void funcJobs(char *file, char *args[]) {
    for (int i = 0; i < MAX_JOBS; ++i) {
        if (jobPids[i] > 0) {
            printf("[%d] %d", i+1, jobPids[i]);
            printf("\n");
        }
    }
}

